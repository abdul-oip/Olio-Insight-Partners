// Main JavaScript for Olio Insight Partners Website

// Smooth Scrolling
function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
    }
}

// Navigation scroll effect
window.addEventListener('scroll', function() {
    const nav = document.getElementById('navbar');
    if (window.scrollY > 100) {
        nav.style.background = 'rgba(11, 25, 41, 0.98)';
        nav.style.boxShadow = '0 5px 20px rgba(0, 0, 0, 0.3)';
    } else {
        nav.style.background = 'rgba(11, 25, 41, 0.95)';
        nav.style.boxShadow = 'none';
    }
});

// Mobile menu toggle
document.addEventListener('DOMContentLoaded', function() {
    const mobileToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileToggle) {
        mobileToggle.addEventListener('click', function() {
            navLinks.classList.toggle('mobile-active');
        });
    }
    
    // Close mobile menu when clicking a link
    const links = document.querySelectorAll('.nav-links a');
    links.forEach(link => {
        link.addEventListener('click', function() {
            navLinks.classList.remove('mobile-active');
        });
    });
});

// Value Modal Functions
function openValueModal() {
    document.getElementById('valueModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeValueModal() {
    document.getElementById('valueModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Demo Modal Functions
function openDemoModal() {
    document.getElementById('demoModal').style.display = 'block';
    document.body.style.overflow = 'hidden';
}

function closeDemoModal() {
    document.getElementById('demoModal').style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Request Demo Access
let currentDemoType = '';

function requestDemoAccess(demoType) {
    currentDemoType = demoType;
    document.getElementById('demoType').value = demoType;
    openDemoModal();
}

// Demo Viewer Functions - Simplified for new window approach
function showDemoViewer(demoType, userEmail) {
    // This function is now handled directly in handleDemoFormSubmit
    // Keeping it for backwards compatibility
    console.log('Demo access granted for:', demoType, userEmail);
}

function closeDemoViewer() {
    const demoViewer = document.getElementById('demo-viewer');
    const demoIframe = document.getElementById('demo-iframe');
    
    if (demoViewer) {
        demoViewer.classList.add('hidden');
        demoViewer.classList.remove('active');
    }
    
    if (demoIframe) {
        demoIframe.src = ''; // Clear iframe
    }
}

// Close modals when clicking outside
window.onclick = function(event) {
    const valueModal = document.getElementById('valueModal');
    const demoModal = document.getElementById('demoModal');
    
    if (event.target === valueModal) {
        closeValueModal();
    }
    if (event.target === demoModal) {
        closeDemoModal();
    }
}

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
        }
    });
}, observerOptions);

// Observe elements for animation
document.addEventListener('DOMContentLoaded', function() {
    const animatedElements = document.querySelectorAll('.metric-card, .service-card, .demo-card');
    animatedElements.forEach(el => observer.observe(el));
});

// Add loading state for buttons
function addButtonLoadingState(button) {
    const originalText = button.textContent;
    button.disabled = true;
    button.textContent = 'PROCESSING...';
    button.classList.add('loading');
    
    return function() {
        button.disabled = false;
        button.textContent = originalText;
        button.classList.remove('loading');
    };
}

// Utility function to validate email
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Add smooth scroll behavior to all anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Initialize any tooltips or popovers
    console.log('Olio Insight Partners website initialized');
});
