// Forms JavaScript - Google Sheets Integration & Email Functionality

// Google Sheets Integration Configuration
const GOOGLE_SCRIPT_URL = 'YOUR_GOOGLE_APPS_SCRIPT_URL'; // Will be replaced with actual URL

// Handle Value Discovery Form Submission
document.addEventListener('DOMContentLoaded', function() {
    const valueForm = document.getElementById('valueForm');
    if (valueForm) {
        valueForm.addEventListener('submit', handleValueFormSubmit);
    }
    
    const demoForm = document.getElementById('demoForm');
    if (demoForm) {
        demoForm.addEventListener('submit', handleDemoFormSubmit);
    }
    
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', handleContactFormSubmit);
    }
});

async function handleValueFormSubmit(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitButton = form.querySelector('button[type="submit"]');
    const resetButton = addButtonLoadingState(submitButton);
    
    // Get form data
    const formData = {
        firstName: form.firstName.value,
        lastName: form.lastName.value,
        email: form.email.value,
        phone: form.phone.value || 'Not provided',
        formType: 'Value Discovery',
        timestamp: new Date().toISOString(),
        source: 'Website - Hero CTA'
    };
    
    // Validate email
    if (!validateEmail(formData.email)) {
        alert('Please enter a valid email address.');
        resetButton();
        return;
    }
    
    try {
        // Send to Google Sheets
        await sendToGoogleSheets(formData);
        
        // Send confirmation email (via Netlify Function)
        await sendConfirmationEmail(formData);
        
        // Show success message
        showSuccessMessage('Thank you for your interest! We will contact you within 24 hours.');
        
        // Close modal and reset form
        closeValueModal();
        form.reset();
        
    } catch (error) {
        console.error('Error submitting form:', error);
        showErrorMessage('There was an error submitting your request. Please try again or email us directly.');
    } finally {
        resetButton();
    }
}

async function handleDemoFormSubmit(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitButton = form.querySelector('button[type="submit"]');
    const resetButton = addButtonLoadingState(submitButton);
    
    // Get form data
    const formData = {
        firstName: form.firstName.value,
        lastName: form.lastName.value,
        email: form.email.value,
        phone: form.phone.value || 'Not provided',
        demoType: form.demoType.value,
        formType: 'Demo Access Request',
        timestamp: new Date().toISOString(),
        source: 'Website - Demo Request'
    };
    
    // Validate email
    if (!validateEmail(formData.email)) {
        alert('Please enter a valid email address.');
        resetButton();
        return;
    }
    
    try {
        // Store access credentials in localStorage for dashboards to read
        localStorage.setItem('olio_dashboard_access', JSON.stringify({
            firstName: formData.firstName,
            lastName: formData.lastName,
            email: formData.email,
            timestamp: Date.now()
        }));
        
        // Send to Google Sheets (if configured)
        await sendToGoogleSheets(formData);
        
        // Send confirmation email (if configured)
        await sendConfirmationEmail(formData);
        
        // Close modal
        closeDemoModal();
        form.reset();
        
        // Open dashboard in new window
        const demoUrls = {
            'revenue-leakage': '/dashboards/revenue-leakage/',
            'kpi-bonus': '/dashboards/kpi-bonus/',
            'pe-integration': '/dashboards/pe-integration/',
            'portfolio-command': '/dashboards/portfolio-command/',
            'compliance-monitor': '/dashboards/compliance-monitor/',
            'physician-attrition': '/dashboards/physician-attrition/',
            'due-diligence': '/dashboards/due-diligence/',
            'workflow-automation': '/dashboards/workflow-automation/'
        };
        
        const dashboardUrl = demoUrls[formData.demoType];
        if (dashboardUrl) {
            // Show success message
            showSuccessMessage('Access granted! Opening dashboard in a new window...');
            
            // Open in new tab after a short delay
            setTimeout(() => {
                window.open(dashboardUrl, '_blank');
            }, 500);
        }
        
    } catch (error) {
        console.error('Error submitting form:', error);
        showErrorMessage('There was an error processing your request. Please try again.');
    } finally {
        resetButton();
    }
}

async function handleContactFormSubmit(e) {
    e.preventDefault();
    
    const form = e.target;
    const submitButton = form.querySelector('button[type="submit"]');
    const resetButton = addButtonLoadingState(submitButton);
    
    // Get form data
    const formData = {
        name: form.name.value,
        email: form.email.value,
        company: form.company.value || 'Not provided',
        message: form.message.value,
        formType: 'Contact Form',
        timestamp: new Date().toISOString(),
        source: 'Website - Contact Section'
    };
    
    // Validate email
    if (!validateEmail(formData.email)) {
        alert('Please enter a valid email address.');
        resetButton();
        return;
    }
    
    try {
        // Send to Google Sheets
        await sendToGoogleSheets(formData);
        
        // Send confirmation email
        await sendConfirmationEmail(formData);
        
        // Show success message
        showSuccessMessage('Thank you for your message! We will respond within 24 hours.');
        
        // Reset form
        form.reset();
        
    } catch (error) {
        console.error('Error submitting form:', error);
        showErrorMessage('There was an error sending your message. Please try again or email us directly.');
    } finally {
        resetButton();
    }
}

// Send data to Google Sheets via Apps Script
async function sendToGoogleSheets(data) {
    // For production, you'll need to set up a Google Apps Script Web App
    // This is a placeholder that shows the structure
    
    try {
        const response = await fetch(GOOGLE_SCRIPT_URL, {
            method: 'POST',
            mode: 'no-cors',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        
        // Note: With no-cors mode, we can't read the response
        // Consider using a Netlify Function as a proxy for better error handling
        console.log('Data sent to Google Sheets');
        
    } catch (error) {
        console.error('Error sending to Google Sheets:', error);
        // For now, we'll store in localStorage as backup
        backupToLocalStorage(data);
    }
}

// Send confirmation email via Netlify Function
async function sendConfirmationEmail(data) {
    try {
        const response = await fetch('/.netlify/functions/send-email', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                to: data.email,
                subject: 'Thank you for contacting Olio Insight Partners',
                data: data
            })
        });
        
        if (!response.ok) {
            throw new Error('Email sending failed');
        }
        
        console.log('Confirmation email sent');
        
    } catch (error) {
        console.error('Error sending email:', error);
        // Continue anyway - don't block the user experience
    }
}

// Backup form data to localStorage if Google Sheets fails
function backupToLocalStorage(data) {
    const backups = JSON.parse(localStorage.getItem('formBackups') || '[]');
    backups.push(data);
    localStorage.setItem('formBackups', JSON.stringify(backups));
    console.log('Form data backed up to localStorage');
}

// Success/Error message display
function showSuccessMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'success-message';
    messageDiv.innerHTML = `
        <div class="message-content">
            <span class="message-icon">✓</span>
            <p>${message}</p>
        </div>
    `;
    
    document.body.appendChild(messageDiv);
    
    // Add styles
    const style = document.createElement('style');
    style.textContent = `
        .success-message {
            position: fixed;
            top: 100px;
            right: 20px;
            background: var(--data-green);
            color: var(--cosmos-black);
            padding: 1rem 2rem;
            border-radius: 5px;
            box-shadow: 0 5px 20px rgba(0, 212, 170, 0.3);
            z-index: 10001;
            animation: slideInRight 0.3s ease;
        }
        
        .message-content {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .message-icon {
            font-size: 1.5rem;
            font-weight: bold;
        }
        
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    `;
    document.head.appendChild(style);
    
    // Remove after 5 seconds
    setTimeout(() => {
        messageDiv.style.animation = 'slideInRight 0.3s ease reverse';
        setTimeout(() => messageDiv.remove(), 300);
    }, 5000);
}

function showErrorMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'error-message';
    messageDiv.innerHTML = `
        <div class="message-content">
            <span class="message-icon">✗</span>
            <p>${message}</p>
        </div>
    `;
    
    document.body.appendChild(messageDiv);
    
    // Add styles
    const style = document.createElement('style');
    style.textContent = `
        .error-message {
            position: fixed;
            top: 100px;
            right: 20px;
            background: var(--mission-red);
            color: white;
            padding: 1rem 2rem;
            border-radius: 5px;
            box-shadow: 0 5px 20px rgba(231, 60, 62, 0.3);
            z-index: 10001;
            animation: slideInRight 0.3s ease;
        }
    `;
    document.head.appendChild(style);
    
    // Remove after 5 seconds
    setTimeout(() => {
        messageDiv.style.animation = 'slideInRight 0.3s ease reverse';
        setTimeout(() => messageDiv.remove(), 300);
    }, 5000);
}

// Export functions for use in other scripts
window.formHandlers = {
    sendToGoogleSheets,
    sendConfirmationEmail,
    showSuccessMessage,
    showErrorMessage
};
