// Netlify Function for sending confirmation emails
// File: netlify/functions/send-email.js

exports.handler = async (event, context) => {
    // Only allow POST requests
    if (event.httpMethod !== 'POST') {
        return {
            statusCode: 405,
            body: JSON.stringify({ error: 'Method not allowed' })
        };
    }

    try {
        const data = JSON.parse(event.body);
        
        // Email template
        const emailBody = `
Dear ${data.data.firstName || data.data.name || 'Valued Client'},

Thank you for exploring Olio Insight Partners' services. We are excited to learn about your healthcare organization's needs and discuss how we can help you achieve operational excellence and financial clarity.

We have received your inquiry and will contact you within 24 hours to schedule a strategic consultation.

Your Information:
- Name: ${data.data.firstName} ${data.data.lastName || ''}
- Email: ${data.data.email}
- Phone: ${data.data.phone || 'Not provided'}
${data.data.demoType ? `- Requested Demo: ${data.data.demoType}` : ''}
${data.data.company ? `- Company: ${data.data.company}` : ''}

In the meantime, here are some ways we've helped similar organizations:
• Achieved $2M+ in annual cost savings through operational optimization
• Improved forecast accuracy by 25% with advanced analytics
• Reduced reporting time by 70% through automation
• Integrated 10+ disparate EHR/PM systems into unified dashboards

Best,

Abdulhamid M. Nur
Olio Insight Partners LLC
Founder & Principal Consultant
anur@olioinsightpartners.com
(571) 337-4207

---
This is an automated response. For immediate assistance, please call us at (571) 337-4207.
        `;

        // In production, you would integrate with an email service like SendGrid or AWS SES
        // For now, we'll simulate success
        console.log('Email would be sent to:', data.to);
        console.log('Email body:', emailBody);

        // Return success response
        return {
            statusCode: 200,
            body: JSON.stringify({ 
                success: true, 
                message: 'Email sent successfully' 
            })
        };

    } catch (error) {
        console.error('Error processing email request:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ 
                error: 'Failed to send email',
                details: error.message 
            })
        };
    }
};
